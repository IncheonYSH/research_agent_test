#!/usr/bin/env node

import { delegateToRootScript, isWindows, writeWindowsAccessDetails } from "./platform-common.mjs";

if (!isWindows()) {
  delegateToRootScript("gpt_web_login/start-chatgpt-tunnel.sh");
} else {
  writeWindowsAccessDetails();
  console.log("Tunnel is not used on Windows local-browser mode.");
  console.log("Use the browser window that was launched locally for manual login.");
}
