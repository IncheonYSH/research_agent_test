#!/usr/bin/env node

import { delegateToRootScript, isWindows, stopWindowsBrowser } from "./platform-common.mjs";

if (!isWindows()) {
  delegateToRootScript("gpt_web_login/stop-chatgpt-remote.sh");
} else {
  stopWindowsBrowser();
}
