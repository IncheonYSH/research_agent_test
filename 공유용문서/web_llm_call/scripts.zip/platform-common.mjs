#!/usr/bin/env node

import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { spawn, spawnSync } from "node:child_process";
import net from "node:net";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const scriptsRoot = path.resolve(__dirname, "../../scripts");
export const runtimeDir = path.resolve(process.env.CHATGPT_RUNTIME_DIR || path.join(scriptsRoot, ".remote-gui"));
export const pidDir = path.join(runtimeDir, "pids");
export const profileDir = path.resolve(process.env.CHATGPT_PROFILE_DIR || path.join(scriptsRoot, ".chatgpt-profile"));
export const accessDetailsPath = path.join(runtimeDir, "access-details.json");
export const tunnelUrlPath = path.join(runtimeDir, "tunnel-url.txt");
export const browserPidPath = path.join(pidDir, "browser.pid");
export const browserUrl = process.env.CHATGPT_URL || "https://chatgpt.com/";
export const cdpPort = Number(process.env.CDP_PORT || "9222");
export const cdpEndpoint = `http://127.0.0.1:${cdpPort}`;

export function ensureRuntimeDirs() {
  fs.mkdirSync(pidDir, { recursive: true });
  fs.mkdirSync(profileDir, { recursive: true });
}

export function isWindows() {
  return process.platform === "win32";
}

export function delegateToRootScript(scriptRelativePath) {
  const command = isWindows() ? "bash.exe" : "bash";
  const scriptPath = path.join(scriptsRoot, scriptRelativePath);
  const result = spawnSync(command, [scriptPath], {
    cwd: scriptsRoot,
    stdio: "inherit",
    env: process.env
  });

  if (result.error) {
    throw result.error;
  }
  process.exit(result.status ?? 1);
}

export function writeAccessDetails(payload) {
  ensureRuntimeDirs();
  fs.writeFileSync(accessDetailsPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
}

export function removeIfExists(filePath) {
  try {
    fs.rmSync(filePath, { force: true });
  } catch {
  }
}

export function readPid(filePath) {
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const text = fs.readFileSync(filePath, "utf8").trim();
  const pid = Number(text);
  return Number.isFinite(pid) && pid > 0 ? pid : null;
}

export function isPidAlive(pid) {
  if (!pid) {
    return false;
  }
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

export async function waitForPort(host, port, timeoutMs = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const ok = await canConnect(host, port);
    if (ok) {
      return;
    }
    await delay(300);
  }
  throw new Error(`Timed out waiting for ${host}:${port}`);
}

export async function canConnect(host, port) {
  return await new Promise((resolve) => {
    const socket = net.createConnection({ host, port });
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("error", () => {
      socket.destroy();
      resolve(false);
    });
  });
}

export function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function resolveBrowserExecutable() {
  const candidates = [
    process.env.CHROME_PATH,
    process.env.GOOGLE_CHROME_BIN,
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
  ].filter(Boolean);

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  try {
    const requireFromScripts = createRequire(path.join(scriptsRoot, "package.json"));
    const { chromium } = requireFromScripts("playwright");
    const executablePath = chromium.executablePath();
    if (executablePath && fs.existsSync(executablePath)) {
      return executablePath;
    }
  } catch {
  }

  return null;
}

export function launchWindowsBrowser() {
  ensureRuntimeDirs();
  const existingPid = readPid(browserPidPath);
  if (existingPid && isPidAlive(existingPid)) {
    console.log(`Browser already running (pid ${existingPid})`);
    writeWindowsAccessDetails();
    return existingPid;
  }

  const browserExecutable = resolveBrowserExecutable();
  if (!browserExecutable) {
    throw new Error("Could not find Chrome/Edge/Playwright Chromium executable on Windows.");
  }

  const args = [
    `--remote-debugging-address=127.0.0.1`,
    `--remote-debugging-port=${cdpPort}`,
    `--user-data-dir=${profileDir}`,
    "--new-window",
    "--start-maximized",
    browserUrl
  ];
  const child = spawn(browserExecutable, args, {
    cwd: scriptsRoot,
    detached: true,
    stdio: "ignore",
    env: process.env
  });
  child.unref();
  fs.writeFileSync(browserPidPath, `${child.pid}\n`, "utf8");
  writeWindowsAccessDetails();
  return child.pid;
}

export function writeWindowsAccessDetails() {
  writeAccessDetails({
    mode: "windows-local-browser",
    localGuiUrl: "(use the browser window that was launched locally)",
    cdpEndpoint,
    manualLoginHint: "A local browser window was launched for manual login. Complete login in that window, then return to the terminal and press Enter."
  });
}

export function stopWindowsBrowser() {
  const pid = readPid(browserPidPath);
  if (!pid) {
    cleanupWindowsRuntimeFiles();
    console.log("No tracked browser process to stop.");
    return;
  }
  const result = spawnSync("taskkill", ["/PID", String(pid), "/T", "/F"], {
    stdio: "ignore",
    env: process.env
  });
  cleanupWindowsRuntimeFiles();
  if (result.error) {
    throw result.error;
  }
  console.log(`Stopped browser pid ${pid}`);
}

export function cleanupWindowsRuntimeFiles() {
  removeIfExists(browserPidPath);
  removeIfExists(accessDetailsPath);
  removeIfExists(tunnelUrlPath);
}
