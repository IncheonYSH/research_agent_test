#!/usr/bin/env node

import { cleanupWindowsRuntimeFiles, delegateToRootScript, isWindows, writeWindowsAccessDetails } from "./platform-common.mjs";

if (!isWindows()) {
  delegateToRootScript("gpt_web_login/stop-chatgpt-tunnel.sh");
} else {
  cleanupWindowsRuntimeFiles();
  writeWindowsAccessDetails();
  console.log("No tunnel was active in Windows local-browser mode.");
}
