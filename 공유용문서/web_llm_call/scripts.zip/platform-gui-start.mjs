#!/usr/bin/env node

import {
  cdpPort,
  delegateToRootScript,
  isWindows,
  launchWindowsBrowser,
  waitForPort,
  writeWindowsAccessDetails
} from "./platform-common.mjs";

async function main() {
  if (!isWindows()) {
    delegateToRootScript("gpt_web_login/start-chatgpt-remote.sh");
    return;
  }

  const pid = launchWindowsBrowser();
  await waitForPort("127.0.0.1", cdpPort, 20000);
  writeWindowsAccessDetails();
  console.log("");
  console.log("Local browser login session is running.");
  console.log(`Tracked browser pid: ${pid}`);
  console.log(`CDP endpoint: http://127.0.0.1:${cdpPort}`);
  console.log("Manual login hint: use the opened browser window, not localhost:7900.");
}

await main();
