#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import random
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, TextIO

MANUAL_ROOT = Path(__file__).resolve().parent
SCRIPTS_ROOT = MANUAL_ROOT.parent / "scripts"
CALL_LOG_ROOT = MANUAL_ROOT / "call_log"
TEMPLATE_ROOT = MANUAL_ROOT / "prompt_template"
DEFAULT_TIMEOUT_MS = 7_200_000
GPT_WEB_MATH_TEXT_MODE_MARKER = "[Web extraction math-text mode]"
GPT_WEB_MATH_TEXT_MODE_SUFFIX = """

[Web extraction math-text mode]
- Output in plain text / Markdown source only.
- Put the entire answer inside exactly one fenced text block that starts with ```text and ends with ```.
- Do not output anything before or after that single fenced block.
- If the prompt already requires a strict machine-readable format such as JSON, place that exact JSON payload verbatim inside the single ```text``` block with no extra commentary.
- Do not rely on rendered math, rich equation widgets, or Unicode pretty-math layout.
- For every equation or symbolic expression, write raw TeX source inside fenced ```tex``` blocks or inline backticks so the literal source remains visible in extracted text.
- Keep notation in literal TeX source form when it matters for downstream parsing.
""".strip()


class CliError(Exception):
    pass


@dataclass(frozen=True)
class ProviderConfig:
    cli_name: str
    display_name: str
    request_id_prefix: str
    request_id_env: str
    timeout_env: str
    prompt_base_cmd: tuple[str, ...]
    gui_start_cmd: tuple[str, ...]
    gui_stop_cmd: tuple[str, ...]
    tunnel_start_cmd: tuple[str, ...]
    tunnel_stop_cmd: tuple[str, ...]
    check_cmd: tuple[str, ...]
    check_name: str


GPT_PRO_CONFIG = ProviderConfig(
    cli_name="gpt_pro_call.py",
    display_name="GPT-5.4 Pro",
    request_id_prefix="pro",
    request_id_env="CHATGPT_REQUEST_ID",
    timeout_env="CHATGPT_RESPONSE_TIMEOUT_MS",
    prompt_base_cmd=(
        "npm",
        "run",
        "chatgpt:handoff",
        "--",
        "--model",
        "GPT-5.4 Pro",
        "--new-chat",
        "--close-page-on-complete",
        "--require-model",
        "--thinking-mode",
        "Extended Thinking",
        "--require-thinking-mode",
    ),
    gui_start_cmd=("npm", "run", "chatgpt:gui:start"),
    gui_stop_cmd=("npm", "run", "chatgpt:gui:stop"),
    tunnel_start_cmd=("npm", "run", "chatgpt:tunnel:start"),
    tunnel_stop_cmd=("npm", "run", "chatgpt:tunnel:stop"),
    check_cmd=("npm", "run", "chatgpt:pro:test:smoke"),
    check_name="smoke-test",
)


GEMINI_CONFIG = ProviderConfig(
    cli_name="gemini_call.py",
    display_name="Gemini Pro 3.1",
    request_id_prefix="gemini",
    request_id_env="GEMINI_REQUEST_ID",
    timeout_env="GEMINI_RESPONSE_TIMEOUT_MS",
    prompt_base_cmd=(
        "npm",
        "run",
        "gemini:handoff",
        "--",
        "--model",
        "Gemini Pro 3.1",
        "--new-chat",
        "--close-page-on-complete",
        "--require-login",
        "--require-model",
    ),
    gui_start_cmd=("npm", "run", "gemini:gui:start"),
    gui_stop_cmd=("npm", "run", "gemini:gui:stop"),
    tunnel_start_cmd=("npm", "run", "gemini:tunnel:start"),
    tunnel_stop_cmd=("npm", "run", "gemini:tunnel:stop"),
    check_cmd=("npm", "run", "gemini:session:check"),
    check_name="session-check",
)


def build_parser(config: ProviderConfig) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            f"Standalone CLI for the {config.display_name} web-call workflow via "
            f"{SCRIPTS_ROOT}."
        )
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the resolved command and environment overrides without running it.",
    )
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    add_static_subcommand(
        subparsers,
        "gui-start",
        config.gui_start_cmd,
        "Start the shared remote browser GUI.",
    )
    add_static_subcommand(
        subparsers,
        "gui-stop",
        config.gui_stop_cmd,
        "Stop the shared remote browser GUI.",
    )
    add_static_subcommand(
        subparsers,
        "tunnel-start",
        config.tunnel_start_cmd,
        "Start the external tunnel for the shared GUI.",
    )
    add_static_subcommand(
        subparsers,
        "tunnel-stop",
        config.tunnel_stop_cmd,
        "Stop the external tunnel for the shared GUI.",
    )

    check_parser = subparsers.add_parser(
        "check",
        aliases=[config.check_name],
        help=f"Run the provider readiness check ({config.check_name}).",
    )
    check_parser.set_defaults(handler=handle_static_command, command=config.check_cmd)

    prompt_parser = subparsers.add_parser(
        "prompt",
        help=f"Send a direct prompt through {config.display_name}.",
    )
    add_request_arguments(prompt_parser)
    prompt_parser.set_defaults(handler=handle_prompt)

    return parser


def add_static_subcommand(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
    name: str,
    command: tuple[str, ...],
    help_text: str,
) -> None:
    parser = subparsers.add_parser(name, help=help_text)
    parser.set_defaults(handler=handle_static_command, command=command)


def add_request_arguments(parser: argparse.ArgumentParser) -> None:
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument("--prompt", help="Raw prompt text to send.")
    input_group.add_argument(
        "--template",
        help="Template name from scripts_manual/prompt_template.",
    )
    parser.add_argument(
        "--ctx",
        help="Text inserted into {ctx} when --template is used.",
    )
    parser.add_argument(
        "--request-id",
        help="Override the generated request id used by the underlying workflow.",
    )
    parser.add_argument(
        "--timeout-ms",
        type=int,
        default=DEFAULT_TIMEOUT_MS,
        help=f"Response timeout forwarded to the workflow. Default: {DEFAULT_TIMEOUT_MS}.",
    )


def handle_static_command(
    args: argparse.Namespace,
    config: ProviderConfig,
) -> tuple[list[str], dict[str, str]]:
    del config
    return list(args.command), {}


def handle_prompt(
    args: argparse.Namespace,
    config: ProviderConfig,
) -> tuple[list[str], dict[str, str]]:
    resolved_prompt = resolve_prompt_text(args)
    resolved_prompt = apply_provider_prompt_overrides(resolved_prompt, args, config)
    args.resolved_prompt = resolved_prompt
    command = [*config.prompt_base_cmd, "--prompt", resolved_prompt]
    return command, build_request_env(args, config, "prompt")


def resolve_prompt_text(args: argparse.Namespace) -> str:
    if args.prompt:
        return args.prompt

    if not args.template:
        raise CliError("Either --prompt or --template is required.")
    if args.ctx is None:
        raise CliError("--ctx is required when using --template.")

    template_path = resolve_template_path(args.template)
    template_text = template_path.read_text(encoding="utf-8")
    if "{ctx}" not in template_text:
        raise CliError(f"Template does not contain {{ctx}}: {template_path}")

    args.template_path = str(template_path)
    rendered = template_text.replace("{ctx}", args.ctx)
    return rendered.strip()


def apply_provider_prompt_overrides(
    prompt_text: str,
    args: argparse.Namespace,
    config: ProviderConfig,
) -> str:
    normalized_prompt = prompt_text.strip()
    if config.cli_name not in {"gpt_pro_call.py", "gemini_call.py"}:
        return normalized_prompt

    if GPT_WEB_MATH_TEXT_MODE_MARKER in normalized_prompt:
        return normalized_prompt

    return f"{normalized_prompt}\n\n{GPT_WEB_MATH_TEXT_MODE_SUFFIX}"


def resolve_template_path(template_name: str) -> Path:
    normalized = template_name.strip()
    if not normalized:
        raise CliError("--template cannot be empty.")

    candidates = [TEMPLATE_ROOT / normalized]
    if Path(normalized).suffix == "":
        candidates.extend(
            TEMPLATE_ROOT / f"{normalized}{suffix}"
            for suffix in (".txt", ".md", ".prompt")
        )

    for candidate in candidates:
        if candidate.is_file():
            return candidate

    raise CliError(
        f"Template not found in {TEMPLATE_ROOT}: {template_name}"
    )


def build_request_env(
    args: argparse.Namespace,
    config: ProviderConfig,
    kind: str,
) -> dict[str, str]:
    request_id = args.request_id or generate_request_id(config.request_id_prefix, kind)
    return {
        config.request_id_env: request_id,
        config.timeout_env: str(args.timeout_ms),
    }


def generate_request_id(prefix: str, kind: str) -> str:
    timestamp = int(time.time())
    pid = os.getpid()
    suffix = random.randint(1000, 9999)
    return f"{prefix}-{kind}-{timestamp}-{pid}-{suffix}"


@dataclass
class ProcessResult:
    returncode: int
    stdout: str
    stderr: str


def execute(
    command: list[str],
    env_overrides: dict[str, str],
    dry_run: bool,
    config: ProviderConfig,
    args: argparse.Namespace,
) -> int:
    if not SCRIPTS_ROOT.is_dir():
        raise CliError(f"Missing scripts root: {SCRIPTS_ROOT}")
    resolved_command = resolve_command(command)

    if dry_run:
        print(f"cwd: {SCRIPTS_ROOT}")
        if env_overrides:
            print(
                "env: "
                + " ".join(
                    f"{key}={shlex.quote(value)}"
                    for key, value in sorted(env_overrides.items())
                )
            )
        print("cmd: " + shlex.join(resolved_command))
        return 0

    process_result = run_subprocess(resolved_command, env_overrides)
    write_prompt_log_if_needed(process_result, config, args)
    return process_result.returncode


def run_subprocess(command: list[str], env_overrides: dict[str, str]) -> ProcessResult:
    env = os.environ.copy()
    env.update(env_overrides)
    try:
        process = subprocess.Popen(
            command,
            cwd=SCRIPTS_ROOT,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
    except FileNotFoundError as exc:
        missing = exc.filename or command[0]
        raise CliError(f"Failed to execute {missing!r}. Is npm installed and available on PATH?") from exc

    assert process.stdout is not None
    assert process.stderr is not None

    captured_stdout: list[str] = []
    captured_stderr: list[str] = []
    threads = [
        threading.Thread(
            target=drain_stream,
            args=(process.stdout, sys.stdout, captured_stdout),
            daemon=True,
        ),
        threading.Thread(
            target=drain_stream,
            args=(process.stderr, sys.stderr, captured_stderr),
            daemon=True,
        ),
    ]
    for thread in threads:
        thread.start()

    returncode = process.wait()
    for thread in threads:
        thread.join()

    return ProcessResult(
        returncode=returncode,
        stdout="".join(captured_stdout),
        stderr="".join(captured_stderr),
    )


def drain_stream(source: TextIO, target: TextIO, captured: list[str]) -> None:
    try:
        for chunk in source:
            captured.append(chunk)
            target.write(chunk)
            target.flush()
    finally:
        source.close()


def write_prompt_log_if_needed(
    process_result: ProcessResult,
    config: ProviderConfig,
    args: argparse.Namespace,
) -> None:
    if args.subcommand != "prompt":
        return

    response_payload = extract_response_payload(process_result.stdout)
    prompt_text = str(getattr(args, "resolved_prompt", "") or getattr(args, "prompt", "") or "")
    response_text = ""
    request_id = ""
    model = ""

    if response_payload is not None:
        prompt_text = str(response_payload.get("prompt", "") or prompt_text)
        response_text = str(response_payload.get("response", "") or "")
        request_id = str(response_payload.get("requestId", "") or "")
        model = str(response_payload.get("model", "") or "")
    elif process_result.stdout:
        request_id = extract_json_string_field(process_result.stdout, "requestId")
        model = extract_json_string_field(process_result.stdout, "model")
        response_text = extract_json_string_field(process_result.stdout, "response")
        if not response_text:
            response_text = recover_response_text_from_raw_stdout(
                process_result.stdout,
                prompt_text,
            )
        if not request_id:
            request_id = extract_json_string_field(process_result.stdout, "request_id")
    if not response_text and process_result.stdout:
        response_text = recover_response_text_from_raw_stdout(
            process_result.stdout,
            prompt_text,
        )

    error_text = process_result.stderr.strip()
    raw_stdout = ""
    raw_stderr = ""
    if response_payload is None:
        raw_stdout = process_result.stdout
        raw_stderr = process_result.stderr
        if not error_text:
            error_text = "Prompt completed without a parseable outer JSON payload."
    if not error_text and process_result.returncode != 0:
        error_text = "Command failed without stderr output."

    log_path = build_log_path(config)
    log_text = render_log_text(
        timestamp=datetime.now(timezone.utc),
        provider=config.display_name,
        request_id=request_id,
        model=model,
        prompt=prompt_text,
        response=response_text,
        exit_code=process_result.returncode,
        error_text=error_text,
        raw_stdout=raw_stdout,
        raw_stderr=raw_stderr,
    )
    CALL_LOG_ROOT.mkdir(parents=True, exist_ok=True)
    log_path.write_text(log_text, encoding="utf-8")


def extract_response_payload(stdout_text: str) -> dict[str, Any] | None:
    decoder = json.JSONDecoder()
    lines = stdout_text.splitlines()
    candidate_indexes = [index for index, line in enumerate(lines) if line.lstrip().startswith("{")]

    for index in reversed(candidate_indexes):
        candidate = "\n".join(lines[index:]).lstrip()
        if not candidate:
            continue
        try:
            payload, _ = decoder.raw_decode(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            return payload
    return None


def extract_json_string_field(stdout_text: str, field_name: str) -> str:
    pattern = re.compile(rf'"{re.escape(field_name)}"\s*:\s*"')
    matches = list(pattern.finditer(stdout_text))
    if not matches:
        return ""

    start = matches[-1].end()
    raw_chars: list[str] = []
    escaped = False
    closed = False
    for character in stdout_text[start:]:
        if escaped:
            raw_chars.append("\\" + character)
            escaped = False
            continue
        if character == "\\":
            escaped = True
            continue
        if character == '"':
            closed = True
            break
        raw_chars.append(character)

    return _decode_json_string_fragment("".join(raw_chars), closed=closed)


def recover_response_text_from_raw_stdout(stdout_text: str, prompt_text: str) -> str:
    candidates: list[str] = []
    normalized_stdout = stdout_text.replace("\r\n", "\n")
    normalized_prompt = prompt_text.replace("\r\n", "\n").strip()

    if normalized_prompt:
        prompt_index = normalized_stdout.rfind(normalized_prompt)
        if prompt_index >= 0:
            candidates.append(normalized_stdout[prompt_index + len(normalized_prompt):])

    handoff_tail = _extract_after_last_handoff_log_line(normalized_stdout)
    if handoff_tail:
        candidates.append(handoff_tail)

    for candidate in candidates:
        cleaned = _clean_recovered_stdout_suffix(candidate)
        if _looks_like_recovered_response(cleaned):
            return cleaned
    return ""


def _extract_after_last_handoff_log_line(stdout_text: str) -> str:
    lines = stdout_text.splitlines()
    last_match_index = -1
    patterns = (
        r"^Started fresh chat page\b",
        r"^Selected model:\b",
        r"^Selected thinking mode\b",
        r"^Opening composer model/thinking pill:\b",
        r"^Session state:\b",
    )
    combined = re.compile("|".join(patterns))
    for index, line in enumerate(lines):
        if combined.search(line):
            last_match_index = index
    if last_match_index < 0:
        return ""
    return "\n".join(lines[last_match_index + 1 :])


def _clean_recovered_stdout_suffix(text: str) -> str:
    stripped_lines = text.replace("\r\n", "\n").splitlines()
    while stripped_lines and not stripped_lines[0].strip():
        stripped_lines.pop(0)
    while stripped_lines and re.match(
        r"^(> agents-scripts-wrapper@|> node |npm ERR!|Session state:|Started fresh chat page|Selected model:|Opening composer model/thinking pill:|Selected thinking mode)",
        stripped_lines[0],
    ):
        stripped_lines.pop(0)
    cleaned = "\n".join(stripped_lines).strip()
    if cleaned.startswith(("'", '"')) and cleaned.count("\n") > 0:
        cleaned = cleaned[1:].lstrip()
    return cleaned.strip()


def _looks_like_recovered_response(text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return False
    if stripped.startswith(("{", "[")):
        return True
    if stripped.startswith(("## ", "### ", "- ", "> ")):
        return True
    nonempty_lines = [line for line in stripped.splitlines() if line.strip()]
    return len(stripped) >= 80 and len(nonempty_lines) >= 2


def _decode_json_string_fragment(raw_text: str, *, closed: bool) -> str:
    candidate = raw_text
    while candidate:
        try:
            return json.loads(f'"{candidate}"')
        except json.JSONDecodeError:
            candidate = candidate[:-1]
    if closed:
        return ""
    return (
        raw_text.replace('\\"', '"')
        .replace("\\n", "\n")
        .replace("\\r", "\r")
        .replace("\\t", "\t")
        .replace("\\\\", "\\")
    ).strip()


def build_log_path(config: ProviderConfig) -> Path:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    base_name = f"{timestamp}_{config.request_id_prefix}"
    candidate = CALL_LOG_ROOT / f"{base_name}.log"
    counter = 1

    while candidate.exists():
        candidate = CALL_LOG_ROOT / f"{base_name}_{counter:02d}.log"
        counter += 1

    return candidate


def render_log_text(
    *,
    timestamp: datetime,
    provider: str,
    request_id: str,
    model: str,
    prompt: str,
    response: str,
    exit_code: int,
    error_text: str,
    raw_stdout: str,
    raw_stderr: str,
) -> str:
    lines = [
        f"timestamp_utc: {timestamp.isoformat()}",
        f"provider: {provider}",
        f"request_id: {request_id}",
        f"model: {model}",
        f"exit_code: {exit_code}",
        "",
        "prompt:",
        prompt,
        "",
        "response:",
        response,
    ]

    if error_text:
        lines.extend(["", "error:", error_text])
    if raw_stdout:
        lines.extend(["", "raw_stdout:", raw_stdout.rstrip()])
    if raw_stderr:
        lines.extend(["", "raw_stderr:", raw_stderr.rstrip()])

    lines.append("")
    return "\n".join(lines)


def run_cli(config: ProviderConfig) -> int:
    parser = build_parser(config)
    args = parser.parse_args()

    try:
        command, env_overrides = args.handler(args, config)
        return execute(command, env_overrides, args.dry_run, config, args)
    except CliError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


def resolve_command(command: list[str]) -> list[str]:
    if not command:
        raise CliError("Empty command.")
    executable = command[0]
    resolved = resolve_executable(executable)
    return [resolved, *command[1:]]


def resolve_executable(executable: str) -> str:
    if os.name == "nt" and executable == "npm":
        for candidate in ("npm.cmd", "npm.exe", "npm"):
            resolved = shutil.which(candidate)
            if resolved:
                return resolved
        raise CliError("npm executable was not found. Install Node.js and ensure npm is on PATH.")

    resolved = shutil.which(executable)
    if resolved:
        return resolved
    return executable
