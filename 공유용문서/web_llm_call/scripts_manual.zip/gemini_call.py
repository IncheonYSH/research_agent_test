#!/usr/bin/env python3
from __future__ import annotations

from _web_call_cli import GEMINI_CONFIG, run_cli


if __name__ == "__main__":
    raise SystemExit(run_cli(GEMINI_CONFIG))
