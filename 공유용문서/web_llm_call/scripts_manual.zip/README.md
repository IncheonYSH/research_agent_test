# scripts_manual

`gpt-pro-call` 과 `gemini-call` 스킬의 실행 흐름을 Codex 스킬 시스템 없이 바로 호출하기 위한 수동 CLI 모음이다.

이 디렉터리의 스크립트는 기존 스킬 파일을 수정하지 않고, `/workspace/scripts` 안에 이미 있는 `npm run ...` 인터페이스를 Python에서 직접 실행한다.
실제 `prompt` 호출이 성공하거나 실패할 때마다 `scripts_manual/call_log` 아래에 타임스탬프 로그 파일을 남긴다.
템플릿은 `scripts_manual/prompt_template` 아래에서 관리하고, 템플릿의 `{ctx}` 자리에 전달한 값을 채워 최종 프롬프트를 만든다.

## Files

- `gpt_pro_call.py`: GPT-5.4 Pro web-call CLI
- `gemini_call.py`: Gemini Pro 3.1 web-call CLI
- `prompt_template/`: 고정 프롬프트 템플릿 저장 위치

## Requirements

- `/workspace/scripts` 가 존재해야 한다.
- 그 디렉터리의 `npm` 의존성이 이미 설치되어 있어야 한다.
- 실제 프롬프트 전송 전에는 각 서비스 로그인 상태가 준비되어 있어야 한다.

## Common commands

직접 실행:

```bash
/workspace/agents/scripts_manual/gpt_pro_call.py --help
/workspace/agents/scripts_manual/gemini_call.py --help
```

또는 Python으로 실행:

```bash
python /workspace/agents/scripts_manual/gpt_pro_call.py --help
python /workspace/agents/scripts_manual/gemini_call.py --help
```

공통 서브커맨드:

- `gui-start`, `gui-stop`
- `tunnel-start`, `tunnel-stop`
- `check`
- `prompt --prompt "..."`
- `prompt --template <name> --ctx "..."`

`check` 는 GPT 쪽에서는 `smoke-test`, Gemini 쪽에서는 `session-check` 의 별칭이다.

## Call logs

- 경로: `/workspace/agents/scripts_manual/call_log`
- 파일명: `YYYYMMDD_HHMMSS_<provider>.log`
- 기록 내용: 입력 프롬프트, 최종 응답, 모델명, request id, 종료 코드

## Prompt templates

- 경로: `/workspace/agents/scripts_manual/prompt_template`
- 선택 방식: `--template echo_ctx` 또는 `--template echo_ctx.txt`
- 치환 규칙: 템플릿 안의 `{ctx}` 를 `--ctx` 값으로 치환
- 테스트용 템플릿: `echo_ctx.txt`
- 아이디어 생성 템플릿: `idea_generator.txt`

## Examples

GPT Pro 준비 확인:

```bash
/workspace/agents/scripts_manual/gpt_pro_call.py gui-start
/workspace/agents/scripts_manual/gpt_pro_call.py check
```

Gemini 세션 확인:

```bash
/workspace/agents/scripts_manual/gemini_call.py gui-start
/workspace/agents/scripts_manual/gemini_call.py check
```

직접 프롬프트:

```bash
/workspace/agents/scripts_manual/gpt_pro_call.py prompt \
  --prompt "Summarize the tradeoff."

/workspace/agents/scripts_manual/gemini_call.py prompt \
  --prompt "Review this approach."
```

템플릿 프롬프트:

```bash
/workspace/agents/scripts_manual/gpt_pro_call.py prompt \
  --template echo_ctx \
  --ctx "TEMPLATE_GPT_OK"

/workspace/agents/scripts_manual/gemini_call.py prompt \
  --template echo_ctx \
  --ctx "TEMPLATE_GEMINI_OK"
```

아이디어 생성 템플릿:

```bash
/workspace/agents/scripts_manual/gpt_pro_call.py prompt \
  --template idea_generator \
  --ctx "Describe the problem here."
```

실행 전 최종 명령만 확인:

```bash
/workspace/agents/scripts_manual/gpt_pro_call.py --dry-run prompt \
  --prompt "hello"
```

로그 예시:

```text
timestamp_utc: 2026-03-13T15:40:12.123456+00:00
provider: GPT-5.4 Pro
request_id: pro-prompt-...
model: ChatGPT 5.4 Pro
exit_code: 0

prompt:
Summarize the tradeoff.

response:
...
```
