#!/usr/bin/env python3
from __future__ import annotations

from _web_call_cli import GPT_PRO_CONFIG, run_cli


if __name__ == "__main__":
    raise SystemExit(run_cli(GPT_PRO_CONFIG))
